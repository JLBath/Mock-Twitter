package edu.uncc.midtermapp;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CreatePostFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CreatePostFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    Button cancelButton, submitButton;
    private static final String ARG_USER_TOKEN = "ARG_USER_TOKEN";
    UserToken mUserToken;
    EditText postEditText;
String inputPost;
boolean textEmpty = true;
    private final OkHttpClient client = new OkHttpClient();

    public CreatePostFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static CreatePostFragment newInstance(UserToken userToken) {
        CreatePostFragment fragment = new CreatePostFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_USER_TOKEN, userToken);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUserToken = (UserToken)getArguments().getSerializable(ARG_USER_TOKEN);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
         View view =  inflater.inflate(R.layout.fragment_create_post, container, false);
        // Inflate the layout for this fragment
        cancelButton= view.findViewById(R.id.cancelButton);
        submitButton = view.findViewById(R.id.submitButton);
        postEditText = view.findViewById(R.id.postEditText);


        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.goBack(mUserToken);
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textEmpty == false){

                    FormBody formBody = new FormBody.Builder()
                            .add("post_text", inputPost) //case sensitive
                            .build();

                    String token = mUserToken.getToken();
                    Request request = new Request.Builder()
                            .url("https://www.theappsdr.com/posts/create")
                            .post(formBody)
                            .addHeader("Authorization", "BEARER " + token)
                            .build();
                    client.newCall(request).enqueue(new Callback() {

                        @Override
                        public void onFailure(@NonNull Call call, @NonNull IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                            try {

                                JSONObject JSONResponse = new JSONObject(response.body().string());
                            //    JSONArray JSONList = JSONResponse.getJSONArray("list");

                            } catch(Exception e){
                                e.printStackTrace();
                            }
                        } //end of onResponse
                    });
                    listener.submit(mUserToken);

                } else {
                    Toast.makeText(getContext(), "Please type your post in the field above", Toast.LENGTH_LONG).show();
                }
            }
        });

        postEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                try {
                    inputPost = postEditText.getText().toString();
                    textEmpty = false;
                } catch (Exception e) {
                    Toast.makeText(getContext(), "Please type your post in the field above", Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                textEmpty = true;
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textEmpty = false;
            }
        });

        return view;
    }




    public CreatePostFragment.CreateListener listener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        listener = (CreatePostFragment.CreateListener) context;
    }

    public interface CreateListener {
        void goBack(UserToken user);
        void submit(UserToken user);
    }
}