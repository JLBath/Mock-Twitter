package edu.uncc.midtermapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PagePostListRecyclerViewAdapter extends RecyclerView.Adapter<PagePostListRecyclerViewAdapter.MyViewHolder>{
    ArrayList<Integer> pages;
    int startPage;
    private OnClickPageListener listener;

    public PagePostListRecyclerViewAdapter(ArrayList<Integer> pages, OnClickPageListener listener) {
        this.pages = pages;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PagePostListRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_button, parent, false);
        MyViewHolder holder = new MyViewHolder(view, listener);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PagePostListRecyclerViewAdapter.MyViewHolder holder, int position) {
        startPage = pages.get(position);

        holder.tv_PageA.setText(String.valueOf(startPage));
    }

    @Override
    public int getItemCount() {
        return this.pages.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tv_PageA;
        OnClickPageListener listener;

        public MyViewHolder(@NonNull View itemView, OnClickPageListener listener) {
            super(itemView);
            tv_PageA = itemView.findViewById(R.id.tv_PageA);
            this.listener = listener; //OnClickPageListener

            //if an error occurs, it might be this
            itemView.setOnClickListener(this);


        }

        @Override
        public void onClick(View view) {
            listener.onPageClick(getAdapterPosition());
        }
    }

    public interface OnClickPageListener {
        void onPageClick(int position);
    }
}
