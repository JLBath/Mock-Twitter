package edu.uncc.midtermapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class PostLRecyclerViewAdapter extends RecyclerView.Adapter<PostLRecyclerViewAdapter.MyViewHolder> {
    ArrayList<Post> postList;
    public RunDelete listener;

    public PostLRecyclerViewAdapter(ArrayList<Post> postList) {
        this.postList = postList;

    }

    @NonNull
    @Override
    public PostLRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_posts, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PostLRecyclerViewAdapter.MyViewHolder holder, int position) {
        Post posts = postList.get(position);
        holder.postContentTV.setText(posts.getText());
        holder.nameTV.setText(posts.getCreatorName());
        holder.timeTV.setText(posts.getDate());

        holder.iv_Trash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setTitle("Delete post?")
                        .setMessage("Do you want to delete this post?")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                RequestBody formBody = new FormBody.Builder()
                                        .add("token", holder.testMethods.mUserToken.getToken())
                                        .add("user_id", holder.testMethods.mUserToken.getUserId())
                                        .add("user_fullname", holder.testMethods.mUserToken.getFullname())
                                        .build();

                                Request request = new Request.Builder()
                                        .url("https://www.theappsdr.com/posts/delete")
                                        .delete(formBody)
                                        .build();
                                holder.client.newCall(request).enqueue(new Callback() {

                                    @Override
                                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                                        e.printStackTrace();
                                    }

                                    @Override
                                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {

                                        if (response.isSuccessful()) {
                                            ResponseBody responseBody = response.body();
                                            String body = responseBody.string();
                                        } else { //on fail
                                            ResponseBody responseBody2 = response.body();
                                            String body2 = responseBody2.string();
                                        }

                                    } //end of on response
                                });
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                builder.create().show();

            }
        });

//        holder.iv_Trash.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
//                builder.setTitle("Delete Post?")
//                        .setMessage("Would you like to delete this post?")
//                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int position) {
//                                //delete post here
//                                Post selectedPost = new Post();
//                                selectedPost = postList.get(position);
//                                postList.remove(selectedPost);
//
//                                Request request = new Request.Builder()
//                                        .url("https://www.theappsdr.com/posts/delete")
//                                        .build();
//                                notifyDataSetChanged();
//                            }
//                        });
//                builder.create().show();
//            }
//        });


//        holder.iv_Trash.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//
//                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
//                builder.setTitle("Delete post?")
//                        .setMessage("Do you want to delete this post?")
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener(){
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                delete();
//                            }
//                        })
//                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//
//                            }
//                        });
//                builder.create().show();
//
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nameTV, postContentTV, timeTV;
        ImageView iv_Trash;
        ConstraintLayout listItem;
        OkHttpClient client = new OkHttpClient();


        ArrayList<Post> postList;
        UserToken mUserToken;
        PostsListFragment testMethods;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            nameTV = itemView.findViewById(R.id.nameTV);
            postContentTV = itemView.findViewById(R.id.postContentTV);
            timeTV = itemView.findViewById(R.id.timeTV);
            iv_Trash = itemView.findViewById(R.id.trashImageView);
        }
    }

    public interface RunDelete {
        void runDelete();
    }
}
