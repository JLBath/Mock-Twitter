package edu.uncc.midtermapp;

public class Post {

//private String id;
private String text;
private String date;
//private String creatorID;
private String creatorName;

private int creatorID, id;


    public Post() {

    }

    public Post(String text, String date, String creatorName, int creatorID, int id) {
        this.text = text;
        this.date = date;
        this.creatorName = creatorName;
        this.creatorID = creatorID;
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCreatorName() {
        return creatorName;
    }

    public void setCreatorName(String creatorName) {
        this.creatorName = creatorName;
    }

    public int getCreatorID() {
        return creatorID;
    }

    public void setCreatorID(int creatorID) {
        this.creatorID = creatorID;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
