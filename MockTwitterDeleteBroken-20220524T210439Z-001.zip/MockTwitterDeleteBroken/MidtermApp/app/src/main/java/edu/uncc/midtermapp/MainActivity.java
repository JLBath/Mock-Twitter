package edu.uncc.midtermapp;
//GroupF9_HW04
//Jacob Mack
//Jenna Bath
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity implements LoginFragment.LoginFragmentListener, CreatePostFragment.CreateListener,SignUpFragment.SignUpFragmentListener , PostsListFragment.PostListener {
    UserToken mUserToken;
    private static final String TAG = "test";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Fetching the stored data
        // from the SharedPreference
        Context context = MainActivity.this;
        SharedPreferences SP_STORAGE = context.getSharedPreferences("SP_STORAGE", Context.MODE_PRIVATE);

        String token = SP_STORAGE.getString("token", "");
        String fullName = SP_STORAGE.getString("user_fullName", "");
        String userId = SP_STORAGE.getString("userId", "");

        mUserToken = new UserToken(token, fullName, userId);
        // Setting the fetched data
        // in the EditTexts
        Log.d(TAG, "onStart: Token Is: " + token.toString() + " And user_fullName Is: " + fullName + " And userId Is: " + userId);
        mUserToken.setToken(token);
        mUserToken.setFullname(fullName);
        mUserToken.setUserId(userId);
    }

    @Override
    public void createAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new SignUpFragment())
                .commit();
    }

    @Override
    public void loginSuccessfulGotoPosts(UserToken userToken) {
        mUserToken = userToken;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void cancelSignUp() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void registerSuccessfulGotoPosts(UserToken userToken) {
        mUserToken = userToken;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }


    @Override
    public void logOut() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void createPostFrag(UserToken user) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, CreatePostFragment.newInstance(user))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void goBack(UserToken user) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(user))
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void submit(UserToken user) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(user))
                .addToBackStack(null)
                .commit();
    }
}