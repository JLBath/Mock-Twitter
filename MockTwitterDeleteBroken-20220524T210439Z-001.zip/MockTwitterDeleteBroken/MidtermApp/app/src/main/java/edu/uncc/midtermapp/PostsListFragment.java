package edu.uncc.midtermapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class PostsListFragment extends Fragment implements PagePostListRecyclerViewAdapter.OnClickPageListener {
    private static final String ARG_USER_TOKEN = "ARG_USER_TOKEN";
    UserToken mUserToken;
    Button logOutButton, createPostButton;
    TextView greetTextView, tv_Page;
    public PostListener postListener;
    ListView postsListView;
    ArrayAdapter<Post> adapter;
    ArrayList<Post> posts = new ArrayList<>();
    ArrayList<Integer> pageHolder = new ArrayList<Integer>();
    ImageView trashImageView;
    int startPage = 1;
    RecyclerView recyclerView, recyclerView2;



    private String TAG = "beep";

    private final OkHttpClient client = new OkHttpClient();


    public PostsListFragment() {
        // Required empty public constructor
    }

    public static PostsListFragment newInstance(UserToken userToken) {
        PostsListFragment fragment = new PostsListFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_USER_TOKEN, userToken);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUserToken = (UserToken)getArguments().getSerializable(ARG_USER_TOKEN);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_posts_list, container, false);
        logOutButton = view.findViewById(R.id.logOutButton);
        createPostButton = view.findViewById(R.id.createPostButton);
        greetTextView = view.findViewById(R.id.greetTextView);
        tv_Page = view.findViewById(R.id.tv_Page);
        recyclerView = view.findViewById(R.id.postsListView);
        recyclerView2 = view.findViewById(R.id.pageRecyclerView);


        @SuppressLint("ResourceType") ImageView iv_Trash = view.findViewById(R.drawable.ic_trash);


        Log.d(TAG, "onCreateView: " + mUserToken);
        logOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteUser();
                postListener.logOut();
            }
        });


        createPostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postListener.createPostFrag(mUserToken);
            }
        });

        String token = mUserToken.getToken();
        String page1 = "?page=1";
        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts" + page1)
                .addHeader("Authorization", "BEARER " + token)
                .build();
        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d(TAG, "fail posts list");

            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                try {
                    JSONObject jsonResponse = new JSONObject(response.body().string());
                    JSONArray postList = jsonResponse.getJSONArray("posts");

                    //POSTS PAGE:
                    int page = jsonResponse.getInt("page");
                    int pageSize = jsonResponse.getInt("pageSize");
                    int totalCount = jsonResponse.getInt("totalCount");

                    int pageTotal = (totalCount / pageSize) + 1;
                    Log.d(TAG, "onResponse: Value?" + "Page : " + page + " Page Size : " + pageSize + " total Count : " + totalCount + " Page Count " + pageTotal);

                    for(int i = 0; i < postList.length(); i++){
                        Post post = new Post();
                        JSONObject item = postList.getJSONObject(i);

                        int id = item.getInt("post_id");
                        String text = item.getString("post_text");
                        String date = item.getString("created_at");
                        int creatorID = item.getInt("created_by_uid");
                        String creatorName = item.getString("created_by_name");


                        post.setId(id);
                        post.setText(text);
                        post.setCreatorID(creatorID);
                        post.setCreatorName(creatorName);
                        post.setDate(date);

                        Log.d(TAG, "onResponse: before" + mUserToken.getUserId() + " check with creatorID " + creatorID);
                        if (mUserToken.getUserId().equals(creatorID)) {
                            iv_Trash.setImageResource(R.drawable.ic_trash);
                            iv_Trash.setVisibility(View.VISIBLE);
                        }

                        Log.d(TAG, "onResponse: after" + mUserToken.getUserId() + " check with creatorID " + creatorID);
                        posts.add(post);
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //POST ADAPTER:
                            RecyclerView recyclerView = view.findViewById(R.id.postsListView);
                            LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
                            recyclerView.setLayoutManager(layoutManager);
                            recyclerView.setHasFixedSize(true);
                            PostLRecyclerViewAdapter adapter = new PostLRecyclerViewAdapter(posts);
                            recyclerView.setAdapter(adapter);

                            tv_Page.setText("Showing page " + page + " out of " + pageTotal);

                            for (int z = 1; z <= pageTotal; z++) {
                                pageHolder.add(z);
                            }

                            //PAGE ADAPTER:
                            RecyclerView recyclerView2 = view.findViewById(R.id.pageRecyclerView);
                            LinearLayoutManager layoutManager2 = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
                            recyclerView2.setLayoutManager(layoutManager2);
                            recyclerView2.setHasFixedSize(true);
                            PagePostListRecyclerViewAdapter adapter2 = new PagePostListRecyclerViewAdapter(pageHolder, PostsListFragment.this);
                            recyclerView2.setAdapter(adapter2);
                        } //end of run
                    });

                } catch(JSONException e){
                    e.printStackTrace();
                }
            } //end of onResponse
        });


        // Inflate the layout for this fragment
        return view;
    }//end of onCreateView

    void deleteUser(){
        //delete authentication token and user information from activity
        Log.d(TAG, "onClick: clicked logout btn");

        mUserToken = null;
        SharedPreferences SP_STORAGE = getActivity().getSharedPreferences("SP_STORAGE", Context.MODE_PRIVATE);
        SharedPreferences.Editor myEdit = SP_STORAGE.edit();

        myEdit.putString("token", "");
        myEdit.putString("user_fullName", "");
        myEdit.putString("userId", "");
        myEdit.apply();

        Log.d(TAG, "onClick: myEdit information After : " + myEdit.toString());
    }

    void delete(){
        RequestBody formBody = new FormBody.Builder()
                .add("token", mUserToken.getToken())
                .add("user_id", mUserToken.getUserId())
                .add("user_fullname", mUserToken.getFullname())
                .build();

        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts/delete")
                .delete(formBody)
                .build();
        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {

                if (response.isSuccessful()) {
                    ResponseBody responseBody = response.body();
                    String body = responseBody.string();
                } else { //on fail
                    ResponseBody responseBody2 = response.body();
                    String body2 = responseBody2.string();
                }

        } //end of on response
    });

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Posts");

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                greetTextView.setText("Hello " + mUserToken.getFullname());
            } //end of run
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        postListener = (PostsListFragment.PostListener) context;
    }

    @Override
    public void onPageClick(int position) {
        //page.get(position)
        //pageHolder.get(position);
        startPage = 1 + position;

        posts.clear();

        String token = mUserToken.getToken();
        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts?page=" + startPage)
                .addHeader("Authorization", "BEARER " + token)
                .build();
        client.newCall(request).enqueue(new Callback() {

            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d(TAG, "fail posts list");
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                try {
                    JSONObject jsonResponse = new JSONObject(response.body().string());
                    JSONArray postList = jsonResponse.getJSONArray("posts");
                    Log.d(TAG, "onResponse: gets here");
                    //POSTS PAGE:
                    int page = jsonResponse.getInt("page");
                    int pageSize = jsonResponse.getInt("pageSize");
                    int totalCount = jsonResponse.getInt("totalCount");

                    int pageTotal = (totalCount / pageSize) + 1;

                    for(int i = 0; i < postList.length(); i++){
                        Post post = new Post();
                        JSONObject item = postList.getJSONObject(i);

                        int id = item.getInt("post_id");
                        String text = item.getString("post_text");
                        String date = item.getString("created_at");
                        int creatorID = item.getInt("created_by_uid");
                        String creatorName = item.getString("created_by_name");


                        post.setId(id);
                        post.setText(text);
                        post.setCreatorID(creatorID);
                        post.setCreatorName(creatorName);
                        post.setDate(date);

//                        Log.d(TAG, "onResponse: before" + mUserToken.getUserId() + " check with creatorID " + creatorID);
//                        if (mUserToken.getUserId().equals(creatorID)) {
//                            iv_Trash.setImageResource(R.drawable.ic_trash);
//                            iv_Trash.setVisibility(View.VISIBLE);
//                        }

                        Log.d(TAG, "onResponse: after" + mUserToken.getUserId() + " check with creatorID " + creatorID);
                        posts.add(post);
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //POST ADAPTER:
                            LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
                            recyclerView.setLayoutManager(layoutManager);
                            recyclerView.setHasFixedSize(true);
                            PostLRecyclerViewAdapter adapter = new PostLRecyclerViewAdapter(posts);
                            recyclerView.setAdapter(adapter);

                            tv_Page.setText("Showing page " + page + " out of " + pageTotal);

                        } //end of run
                    });

                } catch(JSONException e){
                    e.printStackTrace();
                }
            } //end of onResponse
        });







        //sends to clicked page and notifies change to adapter
//        adapter.notifyDataSetChanged();
//        adapter.notifyDataSetChanged();
        Log.d(TAG, "onPageClick: " + startPage);

    }

    

    public interface PostListener {
        void logOut();
        void createPostFrag(UserToken user);
    }
}